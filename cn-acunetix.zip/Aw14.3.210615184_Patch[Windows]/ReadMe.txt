1、将wvsc.exe文件放置于Acunetix安装目录，与原文件进行替换；
2、将license_info.json、wa_data.dat文件放置于C:\ProgramData\Acunetix\shared\license目录，与原文件进行替换即可。

By：Fahai.Org