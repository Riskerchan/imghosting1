简数采集-Emlog发布插件

安装使用说明：
1、在Emlog网站后台，打开 “系统”-》“插件”页面点击“选择文件”选取keydatas.zip ,再“上传安装”
2、点击“开启”
3、点击“设置插件”，可查看基本信息、修改发布密码、设置标题去重等信息。

更多帮助见：
http://doc.keydatas.com/shuju-fabu-daochu/emlog.html

简数官网http://www.keydatas.com/ 