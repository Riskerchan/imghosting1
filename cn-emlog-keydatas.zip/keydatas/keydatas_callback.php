<?php


if(!defined('EMLOG_ROOT')) {exit('error!');}

function callback_init(){
	$DB = MySql::getInstance();
	$is_exist_option = $DB->query("SELECT 1 FROM ".DB_PREFIX."options WHERE option_name='keydatas'");
	if (!$DB->num_rows($is_exist_option)) {
		$DB->query("INSERT INTO ".DB_PREFIX."options (option_name, option_value) VALUES('keydatas', '".serialize(array())."')");
	}	
}