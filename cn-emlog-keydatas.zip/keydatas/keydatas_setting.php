<?php


   !defined('EMLOG_ROOT') && exit('access deined!');

   $keydatasArray = unserialize(Option::get('keydatas'));

   $keydatas_password = $keydatasArray['keydatas_password'];
   if (empty($keydatas_password)){
      $keydatas_password= 'keydatas.com';
   }
   $keydatas_title_unique = $keydatasArray['keydatas_title_unique'];
   if (empty($keydatas_title_unique)){
      $keydatas_title_unique='true';
   }
   
   
   function plugin_setting_view(){
      $keydatasArray = unserialize(Option::get('keydatas'));

   }

?>
<!doctype html>
<style type="text/css">
	.calendar { background: url(<?php echo BLOG_URL; ?>content/plugins/keydatas/skins/default/calendar.gif) no-repeat right 1px; cursor: pointer; padding-right: 20px; border: 1px solid #ABADB3; outline: 0 none; height: 18px; width: 160px; }
</style>
<script type="text/javascript" src="<?php echo BLOG_URL; ?>content/plugins/keydatas/lhgcalendar.min.js"></script>
<script type="text/javascript">
$(function(){
$('#keydatas').addClass('sidebarsubmenu1');
$('input.calendar').calendar({format: 'yyyy-MM-dd HH:mm:ss'});
})
</script>
<div class="containertitle"><b>简数采集和发布接口配置</b>
<?php if(isset($_GET['setting'])):?><span class="actived">插件设置完成</span><?php endif;?>
<?php if(isset($_GET['error'])):?><span class="error">插件设置失败</span><?php endif;?>
</div>
<div class="line"></div>
<p><b>内容发布设置：</b></p>
<form action="plugin.php?plugin=keydatas&action=setting" method="post">
   <table width="100%" class="config-table">
	<tr>
            <td width="15%">网站发布地址为:</td>
            <td width="85%"><input size="36" type="text" id="homeUrl"  name="homeUrl" class="config-input" readonly value="<?php
                                if (isset($_SERVER["HTTPS"]) && strtolower($_SERVER["HTTPS"]) == "on") {
                                    echo "https://";
                                } else {
                                    echo "http://";
                                }
                                $domain = str_replace('\\', '/', $_SERVER['HTTP_HOST']);
                                echo $domain; ?>" />（采集和发布数据请到 <a href="http://dash.keydatas.com" target="_blank">简数控制台</a>）
            
            </td>
          </tr>
          <tr>
            <td width="15%">发布密码:</td>
            <td width="85%"><input size="36" type="text" name="keydatas_password" class="config-input" value="<?php echo $keydatas_password; ?>" />（请注意修改并保管好,到 <a href="http://dash.keydatas.com" target="_blank">简数控制台</a>发布需要用到）
            </td>
          </tr>
		  <tr>
			<td width="15%">根据标题去重:</td>
			<td width="85%"><input type="checkbox" name="keydatas_title_unique" value="true" <?php if($keydatas_title_unique == 'true') echo "checked='checked'" ?> />存在相同标题，则不插入
			</td>
		</tr>
		
		
	      <tr>
            <td><input type="submit" name="formSubmit" value="保 存" class="submit" />
			</td>
			<td></td>
          </tr>
   </table>	
</form>
<div class="line"></div>
<div class="info-box">
    <h3>简介和使用教程</h3>
    <div>
      <table width="100%" class="config-table">
        <tr>
          <td width="15%">简数官网:</td>
          <td><a href="http://www.keydatas.com" target="_blank">www.keydatas.com</a> &nbsp;&nbsp;&nbsp;&nbsp;QQ交流群：542942789</td>
        </tr>		
        <tr>
          <td>采集和发布教程：</td>
          <td><a href="http://doc.keydatas.com/getting-started.html" target="_blank" title="数据采集快速入门">网站采集快速入门</a>
		  <!--&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="http://www.keydatas.com/doc/fuyYRzrY7vy2" target="_blank" title="微信公众号文章采集">微信公众号文章采集</a>-->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		  <a href="http://doc.keydatas.com/shuju-fabu-daochu/emlog.html" target="_blank">发布到Emlog教程</a>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="http://www.keydatas.com/doc/fuyYRzrY7vy2" target="_blank" title="微信公众号文章采集">微信公众号文章采集教程</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="http://doc.keydatas.com/task/toutiao.html" target="_blank" title="今日头条采集">今日头条采集教程</a></td>
		</tr>
        <tr>
          <td>平台主要功能特性：</td>
          <td>
		  <div class="feature">1.采集不需安装任何客户端，<strong>在线可视化点选</strong>；</div>
		  <div class="feature">2.集成智能提取引擎(国内独家),自动识别数据和规则，包括：翻页、标题，作者，发布日期，内容等,<strong>甚至不需修改即可开始采集</strong>;</div>
		  <div class="feature">3.图片下载支持存储到：阿里云OSS、七牛云、腾讯云;（支持水印、压缩等）</div>
		  <div class="feature">4.<strong>全自动化：定时采集+自动发布</strong>;</div>
		  <div class="feature">5.提供强大的<a href="http://doc.keydatas.com/task/seo.html" target="_blank" >SEO工具</a>，包括：<a href="http://doc.keydatas.com/task/seo/seo-tool/insert-dynamic-para.html" target="_blank" >正文插入动态段落(强烈推荐)</a>、正文插入段落及标题自动关键词、自动内链、同义词替换、简繁体转换、翻译等；</div>
		  <div class="feature">6.免费、自动接入多家IP代理服务商等。</div>
		  <div class="feature">7.与Emlog系统无缝结合，点击几下就可以发布到Emlog系统中。</div>
		  <div class="feature">8.支持微信公众号文章采集(包括采集公众号历史文章)、今日头条新闻采集，仅需输入微信公众号ID或者头条号或者关键词即可采集；</div>
		  </td>
        </tr>		
      </table>
    </div>
  </div>

<?php 
function plugin_setting(){

   $kds_title_unique = $_POST['keydatas_title_unique'];
   $keydatas_title_unique = !isset($kds_title_unique)||empty($kds_title_unique)?"false":$kds_title_unique;
   $keydatas_password = isset($_POST['keydatas_password'])?$_POST['keydatas_password']:'';
		
   $keydatasArray['keydatas_password'] = $keydatas_password;
   $keydatasArray['keydatas_title_unique'] = $keydatas_title_unique;
		
   Option::updateOption('keydatas', serialize($keydatasArray));
   $CACHE = Cache::getInstance();
   $CACHE->updateCache('options');
}
?>