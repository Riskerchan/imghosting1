简数采集-Typecho发布插件

安装使用说明：
1、解压后，将文件夹keydatas上传到Typecho网站的usr/plugins目录下。插件更新方法也相同。
2、文件上传成功后，使用管理员帐户登陆Typecho网站后台
3、在Typecho网站后台，打开 “控制台”-》“插件”，点击“启用”插件，
4、点击“设置”，可查看基本信息、修改发布密码、设置标题去重等信息。


更多帮助见：
http://doc.keydatas.com/shuju-fabu-daochu/typecho.html

简数官网http://www.keydatas.com/ 