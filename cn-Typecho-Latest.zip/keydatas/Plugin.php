<?php

/**
 * 简数采集(keydatas.com)是一个通用、简单、智能、在线的网页数据采集和发布平台，功能强大，操作简单。支持定时采集+自动发布，定时发布，站群发布；   集成强大的数据处理和SEO优化工具；支持微信公众号文章(包括采集公众号历史文章)、今日头条、新闻泛采集等一键采集；集成翻译和同义词替   换等服务；图片下载支持存储到阿里云OSS、七牛对象存储、腾讯云对象存储，并支持压缩和水印；免费自动接入多家IP代理商。
 * @package 简数采集和发布平台
 * @author keydatas
 * @version 1.0.1
 * @link http://www.keydatas.com/
 *
 */
 
//class KeyDatas_Plugin implements Typecho_Plugin_Interface
class keydatas_Plugin implements Typecho_Plugin_Interface {

    public static function activate() {
			Typecho_Plugin::factory('index.php')->begin = array('keydatas_Plugin', 'post');
    }
   
    public static function deactivate() {
			Helper::removeAction("__kds_flag");
    }  
   
     public static function post() {
        $uri = $_SERVER['REQUEST_URI'];
				if(strpos($uri,"?__kds_flag=") !== false){
            require_once ( __DIR__."/Kds_typecho.php");
            $kdsTypecho = @new Kds_typecho(Typecho_Request::getInstance(),Typecho_Response::getInstance());
            $kdsTypecho->action();
        }
    }   

    public static function config(Typecho_Widget_Helper_Form $form) {
        $siteUrl = Helper::options()->siteUrl;
        $publishUrlLabel = new Typecho_Widget_Helper_Layout("label", array(
            'class' => 'typecho-label',
            'style' => 'margin-top:20px;'
        ));
        $publishUrlLabel->html('网站发布地址为：');
        $publishUrl = new Typecho_Widget_Helper_Layout("input",
            array(
                "disabled" => true,
                "readOnly" => true,
                "value" => $siteUrl,
                'type' => 'text',
                'class' => 'text',
                'style' => "width:80%;height:80%;"
            )
        );

        $rootDiv = new Typecho_Widget_Helper_Layout();
        $urldiv = new Typecho_Widget_Helper_Layout();
        $urldiv->setAttribute('class', 'typecho-option');
        $publishUrlLabel->appendTo($urldiv);
        $publishUrl->appendTo($urldiv);
        $form->addItem($urldiv);

        $kds_password = new Typecho_Widget_Helper_Form_Element_Text('kds_password', null, 'keydatas.com', _t('发布密码：'), "（请注意修改并保管好,简数控制台发布需要用到）");

         // 文章标题去重选项
        $duplicateOptions = array(
		   		'no_keydatas_title_unique' => _t('根据标题去重，如存在相同标题，则不插入')
		   	);
				$duplicateOptionsValue = array('no_keydatas_title_unique');
	    	$keydatas_title_unique = new Typecho_Widget_Helper_Form_Element_Checkbox('keydatas_title_unique', $duplicateOptions,
            $duplicateOptionsValue, _t('标题去重:'));

        $form->addInput($kds_password);
				$form->addInput($keydatas_title_unique->multiMode());
        $helperLayout = new Typecho_Widget_Helper_Layout();
        $itemOne_p = new Typecho_Widget_Helper_Layout('span', array(
            'style' => "floal:left;display:block;clear:left;margin-top:10px;"
        ));
        $itemOne_p->html("简介和使用教程：");
        $itemOne_ul = new Typecho_Widget_Helper_Layout('ul');
        $itemOne_ul->setAttribute('class', 'typecho-option');
        $itemOne_li0 = new Typecho_Widget_Helper_Layout('li');
        $itemOne_li0->html('简数采集是一个简单、智能、在线的网页数据采集和发布平台，功能强大，操作简单。已获得广大用户的一致好评，保证你也会喜欢上它！采集和发布数据请到 <a href="http://dash.keydatas.com" target="_blank">简数控制台</a>');

        $itemOne_li1 = new Typecho_Widget_Helper_Layout('li');
        $descText = '1、简数官网<a href="http://www.keydatas.com" target="_blank">www.keydatas.com</a> &nbsp;&nbsp;&nbsp;&nbsp;QQ交流群：542942789</br>'.
		        '2、采集和发布教程：<a href="http://doc.keydatas.com/getting-started.html">数据采集快速入门</a>'.
		        '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="http://doc.keydatas.com/shuju-fabu-daochu/typecho.html">发布到Typecho教程</a>'.
		        '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="http://www.keydatas.com/doc/fuyYRzrY7vy2">微信公众号文章采集教程</a>'.
		        '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="http://doc.keydatas.com/task/toutiao.html">今日头条采集教程</a></br>'.
				'3.采集不需安装任何客户端，<strong>在线可视化点选</strong></br>'.
				'4.集成智能提取引擎(国内独家),自动识别数据和规则，包括：翻页、标题，作者，发布日期，内容等,<strong>甚至不需修改即可开始采集</strong></br>'.
				'5.图片下载支持存储到：阿里云OSS、七牛云、腾讯云;（支持水印、压缩等）</br>'.
				'6.<strong>全自动化：定时采集+自动发布</strong></br>'.
				'7.提供强大的<a href="http://doc.keydatas.com/task/seo.html" target="_blank" >SEO工具</a>，包括：<a href="http://doc.keydatas.com/task/seo/seo-tool/insert-dynamic-para.html" target="_blank" >正文插入动态段落(强烈推荐)</a>、正文插入段落及标题自动关键词、自动内链、同义词替换、简繁体转换、翻译等。</br>'.
				'8.免费、自动接入多家IP代理服务商等。</br>'.
				'9.与Typecho系统无缝结合，点击几下就可以发布到Typecho系统中。</br>'.
				'10.支持微信公众号文章采集(包括采集公众号历史文章)、今日头条新闻采集，仅需输入微信公众号ID或者头条号或者关键词即可采集';	
        $itemOne_li1->setAttribute('class', 'description')->html($descText);
        $itemOne_ul->addItem($itemOne_li0);
        $itemOne_ul->addItem($itemOne_li1);
        $helperLayout->addItem($itemOne_p);
        $helperLayout->addItem($itemOne_ul);

        $form->addItem($helperLayout);
        $form->appendTo($rootDiv);
    }

    public static function personalConfig(Typecho_Widget_Helper_Form $form) {
    }
 
}
